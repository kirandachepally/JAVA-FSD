package sort;

public class Main
{
	public static void main(String[] args) {
		Smallest ob = new Smallest(); 
        int arr[] = {10, 30, 5, 9, 4, 19, 26}; 
        int n = arr.length,k = 2; 
        System.out.println("K'th smallest element is "+ ob.kthSmallest(arr, 0, n-1, k)); 
    }
}
