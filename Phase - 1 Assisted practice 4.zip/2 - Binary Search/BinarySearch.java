package assisted4;


public class BinarySearch {
	
    public static void main(String[] args) {
        int[] arr = {3, 6, 9, 12, 15};
        int key = 15;
        int result = binarySearch(arr, key);
        
        if (result == -1) {
            System.out.println("Element is not found");
        } else {
            System.out.println("Element is found at index: " + result);
        }
    }

    public static int binarySearch(int[] arr, int key) {
        int start = 0;
        int end = arr.length - 1;
        
        while (start <= end) {
            int mid = start + (end - start) / 2;

            if (arr[mid] == key) {
                return mid;
            } else if (arr[mid] < key) {
                start = mid + 1;
            } else {
                end = mid - 1;
            }
        }
        
        return -1;
    }
}


