package assisted4;

import java.util.Arrays;

public class ExponentialSearch {

    public static void main(String[] args) {
        int[] arr = {8, 2, 9, 22, 40};
        int value = 9;
        int outcome = exponentialSearch(arr, value);

        if (outcome < 0) {
            System.out.println("Element is not present in the array");
        } else {
            System.out.println("Element is present in the array at index: " + outcome);
        }
    }

    public static int exponentialSearch(int[] arr, int value) {
        int length = arr.length;

        if (arr[0] == value) {
            return 0;
        }

        int i = 1;
        while (i < length && arr[i] <= value) {
            i = i * 2;
        }

        int low = i / 2;
        int high = Math.min(i, length);
        return Arrays.binarySearch(arr, low, high, value);
    }

}

